from read_dataset import *
from preprop import *
from model import segmentation_model
import torch
from torch.utils.data import DataLoader, TensorDataset

def train(img_list, gt_list, model, epoch, learning_rate, optimizer, criterion, data_len, batch_size):
    img_list = [torch.tensor(img, dtype=torch.float32) for img in img_list]
    gt_list = [torch.tensor(gt, dtype=torch.long) for gt in gt_list]
    dataset = TensorDataset(torch.stack(img_list), torch.stack(gt_list))
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


    for e in range(epoch):
        running_loss = 0.0

        for batch_idx, (img_tensor, gt_tensor) in enumerate(dataloader):
            img_tensor = img_tensor.to(device)
            gt_tensor = gt_tensor.squeeze(1).to(device)

            optimizer.zero_grad()

            outputs = model(img_tensor)
            loss = criterion(outputs, gt_tensor)
            
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            
            if (batch_idx % 100 == 0) and (batch_idx != 0):
                print(f'Epoch: {e+1}, Iteration: {batch_idx}, Loss: {running_loss / (batch_idx + 1)}')
        
        # 매 epoch 후 모델 저장
        torch.save(model.state_dict(), f'model_state_dict_epoch_{e+1}.pth')