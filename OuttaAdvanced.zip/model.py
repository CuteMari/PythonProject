import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.models as models
import torchvision.models.vgg as vgg
import torch.nn.init as init
import torch.nn.functional as F
import math


# 모델의 층을 초기화 시킬 때 쓴 코드로, 필요하지 않으시다면 사용하지 않으셔도 됩니다.
# bilinear interpolation을 사용하여 업샘플링 층의 가중치를 초기화하는 데 사용
# 업샘플링 층이 이미지나 피처맵의 크기를 늘릴 때, 기존의 정보를 최대한 보존하면서 부드럽게 확장하도록 

def get_upsampling_weight(in_channels, out_channels, kernel_size):
    # 필터의 중심점을 찾기 위해 사용되는 factor
    factor = (kernel_size + 1) // 2

    # 필터 크기 kernel_size가 홀수인지 짝수인지에 따라 center 값을 결정
    if kernel_size % 2 == 1:
        center = factor - 1
    else:
        center = factor - 0.5

    # np.ogrid는 열린 그리드를 생성하는 NumPy 함수
    # kernel_size x kernel_size 크기의 그리드를 생성
    # og[0]: 첫 번째 축에 대한 인덱스를 가진 (kernel_size, 1) 형태의 배열. -> 행
    # og[1]: 두 번째 축에 대한 인덱스를 가진 (1, kernel_size) 형태의 배열. -> 열
    og = np.ogrid[:kernel_size, :kernel_size]

    # og[0] - center는 행 방향에서 각 위치와 중심점 사이의 거리를 계산
    # og[1] - center는 열 방향에서 각 위치와 중심점 사이의 거리를 계산
    filt = (1 - abs(og[0] - center) / factor) * \
           (1 - abs(og[1] - center) / factor)

    weight = np.zeros((in_channels, out_channels, kernel_size, kernel_size),
                      dtype=np.float64)

    weight[range(in_channels), range(out_channels), :, :] = filt

    return torch.from_numpy(weight).float()


class segmentation_model(nn.Module):
    def __init__(self, n_class):
        super(segmentation_model, self).__init__()
        
        self.features = models.vgg16(pretrained=True).features

        self.upsampling1 = nn.ConvTranspose2d(512, 512, kernel_size=3, stride=2, padding=1, output_padding=1)
        self.upsampling2 = nn.ConvTranspose2d(512, 256, kernel_size=3, stride=2, padding=1, output_padding=1)
        self.upsampling3 = nn.ConvTranspose2d(256, 128, kernel_size=3, stride=2, padding=1, output_padding=1)
        self.upsampling4 = nn.ConvTranspose2d(128, 64, kernel_size=3, stride=2, padding=1, output_padding=1)
        self.upsampling5 = nn.ConvTranspose2d(64, n_class, kernel_size=3, stride=2, padding=1, output_padding=1)


        self.relu = nn.ReLU(inplace=True)
        self.dropout = nn.Dropout2d(p=0.5)
        self._initialize_weights()
        

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
    
        

    def forward(self, x):
        original_size = x.size()[2:]
        
        x = self.features(x)
        x = self.relu(self.upsampling1(x))
        x = self.dropout(x)
        x = self.relu(self.upsampling2(x))
        x = self.dropout(x)
        x = self.relu(self.upsampling3(x))
        x = self.dropout(x)
        x = self.relu(self.upsampling4(x))
        x = self.dropout(x)
        x = self.upsampling5(x)
        
        x = F.interpolate(x, size=original_size, mode='bilinear', align_corners=False)
        

        return x
  
  