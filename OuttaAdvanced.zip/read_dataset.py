import numpy as np
import h5py

# HDF5 파일 형식으로 저장된 데이터셋을 읽어들임
# 구체적으로는 이미지와 그라운드 트루스 데이터를 불러오는 역할을 함
'''
file_path: HDF5 파일의 경로
data_len: 읽어들일 데이터의 개수
'''

def read_dataset(file_path, data_len):
    img_list = []   # 불러온 이미지 데이터를 담는 리스트
    gt_list = []    # 불러온 그라운드 트루스 데이터를 담은 리스트
    
    # hdf5파일 읽기 전용으로 불러옴
    with h5py.File(file_path, 'r') as file:
        # 각 데이터셋 로드
        data_img = file['ih']
        data_gt = file['b_']
        
        # 길이만큼 데이터 불러오기
        for i in range(data_len):
            img_list.append(np.array(data_img[i]))
            gt_list.append(np.array(data_gt[i]))
    
    return img_list, gt_list