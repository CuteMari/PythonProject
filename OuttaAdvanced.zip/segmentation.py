import numpy as np
import torch
from PIL import Image
# 이미지 세그멘테이션을 수행하여 각 픽셀에 대해 모델이 예측한 클래스를 시각적으로 표현
# 결과는 주어진 클래스에 따라 특정 색상으로 표현된 이미지!

'''
mask: 모델의 출력으로 얻은 2D배열이며 각 픽셀은 특정 클래스에 할당됨
num_classes: 클래스 개수
output: 마스크에 따라 색상이 입혀진 RGB 이미지 (numpy 배열)
'''
def segmentation_output(mask, num_classes=7):
    label_colours = [(0, 0, 0), (0, 0, 0), (0, 0, 0),(256, 256, 256), (0, 0, 0), (0,0,0), (0,0,0)]
    # 0: 전신, 1: 머리카락, 2: 머리~목, 3: 상의, 4: 바지, 5: 배경, 6: 팔
    

    h, w = mask.shape
    img = Image.new('RGB', (w, h))
    pixels = img.load()
    for j_, j in enumerate(mask[:, :]):
        for k_, k in enumerate(j):
            if k < num_classes:
                pixels[k_, j_] = label_colours[k]
    output = np.array(img)

    return output


# 이미지 segmentation
'''
image: 입력 이미지 (numpy 배열, 크기: (h, w, channels))
model: 이미지 세그멘테이션 모델
'''
def segementation(image, model):
    # 이미지를 (channel, h, w)형식으로 변환
    test_conv = image.transpose(2, 0 ,1)        

    # 배치 차원 추가
    test_conv1 = test_conv[np.newaxis, :, :, :] 

    # 텐서로 변환
    test_conv_tensor = torch.from_numpy(test_conv1.copy()).float()  

    # 모델을 사용하여 이미지 처리 -> 각 픽셀의 클래스를 나타내는 출력 반환함
    conv_out_model = model(test_conv_tensor)
    output_model = torch.argmax(conv_out_model, dim=1)

    # segmenation_output 함수 호출하여 시각적 결과를 얻는다
    vis_output_model = segmentation_output(output_model[0].data.cpu().numpy())
    return vis_output_model